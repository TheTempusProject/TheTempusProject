failure of the application
general server error