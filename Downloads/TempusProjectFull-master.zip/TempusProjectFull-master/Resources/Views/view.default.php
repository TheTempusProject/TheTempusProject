<h1>This is a default view </h1>
<p>It is comprised entirely of free form HTML</p>
<p>If you are feeling extra bold you can use the templating engine to set variables to be replaced at runtime such as {variable} or even {variable2}, or maybe even just look through some data:</p>
{loop}
{value1} is the first value.<br />
{value2} is the second value.<br />
{value3} is the thisrd value.<br />
{/loop}
{ALT}No Loop{/ALT}
{footer}