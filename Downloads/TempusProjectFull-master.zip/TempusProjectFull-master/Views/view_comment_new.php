<form action="" method="post" class="form-horizontal">
    <div class="form-group center-block">
        <div class="col-lg-8 col-lg-offset-2">
            <textarea class="form-control" name="comment" maxlength="2000" rows="4" cols="50" id="comment"></textarea>
        </div>
    </div>
    <button name="submit" value="submit" type="submit" class="btn btn-lg btn-primary center-block">Comment</button>
    <input type="hidden" name="token" value="{TOKEN}">
</form>