<form action="" method="post" class="form-horizontal">
    <div class="form-group center-block">
        <div class="col-lg-4 col-lg-offset-4">
            <textarea class="form-control" name="comment" maxlength="2000" rows="10" cols="50" id="comment">{content}</textarea>
        </div>
    </div>
    <button name="submit" value="submit" type="submit" class="btn btn-lg btn-primary center-block">Comment</button>
    <input type="hidden" name="token" value="{TOKEN}">
</form>