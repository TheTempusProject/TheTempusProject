<ul class="nav nav-tabs" role="tablist">
	<li role="presentation"><a href="{BASE}usercp">Profile</a></li>
	<li role="presentation"><a href="{BASE}usercp/settings">Settings</a></li>
    <li role="presentation"><a href="{BASE}usercp/email">Change Email</a></li>
    <li role="presentation"><a href="{BASE}usercp/password">Change Password</a></li>
    <li role="presentation"><a href="{BASE}usercp/messages">Messages</a></li>
</ul>