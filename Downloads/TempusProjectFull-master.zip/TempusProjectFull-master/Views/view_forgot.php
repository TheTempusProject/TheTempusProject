<form action="" method="post" class="form-horizontal">
    <legend>Lost and Found</legend>
    <fieldset>
        <div class="form-group">
            <label for="entry" class="col-lg-3 control-label">Username or Email:</label>
            <div class="col-lg-3">
                <input class="form-control" type="text" name="entry" id="entry">
            </div>
        </div>
    </fieldset>
    <input type="hidden" name="token" value="{TOKEN}">
    <button name="submit" value="submit" type="submit" class="btn btn-lg btn-primary center-block">Reset Password</button><br>
</form>