<div class="copy">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center">
	    <p class="text-muted">Powered by <a href="https://www.thetempusproject.com">The Tempus Project</a>.</p>
	</div>
</div>