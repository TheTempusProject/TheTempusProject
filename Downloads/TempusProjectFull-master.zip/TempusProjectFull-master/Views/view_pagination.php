<ul class="pagination">
{LOOP}
<li{ACTIVEPAGE}><a href="?page={PAGENUMBER}">{LABEL}</a></li>
{/LOOP}
</ul>