<legend>Admin Dashboard</legend>
<div class="row">
    <div class="col-xlg-6 col-lg-6 col-md-6 col-sm-6 col-xs-6">
        {userDash}
    </div>
    <div class="col-xlg-6 col-lg-6 col-md-6 col-sm-6 col-xs-6">
        {commentDash}
    </div>
</div>
<div class="row">
    <div class="col-xlg-12 col-lg-12 col-md-12 col-sm-12 col-xs-12">
        {blogDash}
    </div>
</div>