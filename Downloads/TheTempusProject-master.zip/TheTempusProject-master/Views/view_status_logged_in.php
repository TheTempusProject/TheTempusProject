<li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">{USERNAME} <i class="fa fa-user"></i></a>
    <ul class="dropdown-menu">
        <li role="presentation"><a href="{BASE}usercp"><i class="fa fa-fw fa-user"></i> Profile</a></li>
        <li role="presentation"><a href="{BASE}usercp/messages"><i class="fa fa-fw fa-envelope"></i> Inbox {MBADGE}</a></li>
        <li role="presentation"><a href="{BASE}usercp/settings"><i class="fa fa-fw fa-gear"></i> Settings</a></li>
        <li class="divider"></li>
        <li>
            <a href="{BASE}home/logout"><i class="fa fa-fw fa-power-off"></i> Log Out</a>
        </li>
    </ul>
</li>