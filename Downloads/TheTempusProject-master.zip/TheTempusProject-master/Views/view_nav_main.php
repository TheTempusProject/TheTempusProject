<ul class="nav navbar-nav">
    <li><a href="{BASE}home/index">Home</a></li>
    <li><a href="{BASE}blog/index">Blog</a></li>
    {MEMBER}<li><a href="{BASE}member">Member</a></li>{/MEMBER}
    {MOD}<li><a href="{BASE}moderator">Moderator</a></li>{/MOD}
    {ADMIN}<li><a href="{BASE}admin">Admin</a></li>{/ADMIN}
</ul>