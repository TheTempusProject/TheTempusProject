<select name="groupSelect" id="groupSelect" class="form-control">
{LOOP}
<option value='{ID}'>{name}</option>
{/LOOP}
</select>