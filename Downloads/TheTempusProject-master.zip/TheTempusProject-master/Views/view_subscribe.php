<form action="{BASE}home/subscribe" method="post" class="form-horizontal">
    <input type="email" placeholder="Email" id="email" name="email">
    <input type="hidden" name="token" value="{TOKEN}">
    <button name="submit" value="submit" type="submit" class="btn btn-lg btn-primary center-block">Submit</button><br>
</form>