<form action="" method="post" class="form-horizontal">
    <p>Please click the resend button to resend your email confirmation. Don't forget to check the spam folder!</p>
    <input type="hidden" name="resendConfirmation" value="true">
    <input type="hidden" name="token" value="{TOKEN}">
    <button name="submit" value="submit" type="submit" class="btn btn-lg btn-primary center-block">Resend Confirmation</button><br>
</form>