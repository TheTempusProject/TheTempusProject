<td class="header" bgcolor="#b5e6ff">
    <table width="70" align="left" border="0" cellpadding="0" cellspacing="0">
        <tr>
            <td height="70" style="padding: 0 20px 20px 0;">
                <img src="{LOGO}" width="70" height="70" border="0" alt="" / >
            </td>
        </tr>
    </table>
    <!--[if (gte mso 9)|(IE)]>
    <table width="425" align="left" cellpadding="0" cellspacing="0" border="0">
    <tr>
    <td>
    <![endif]-->
    <table class="col425" align="left" border="0" cellpadding="0" cellspacing="0" style="width: 100%; max-width: 425px;">
        <tr>
            <td height="70">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tr>
                        <td class="subhead" style="padding: 0 0 0 3px;">
                            {BASE}
                        </td>
                    </tr>
                    <tr>
                        <td class="h1" style="padding: 5px 0 0 0;">
                            {SITENAME}
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
    <!--[if (gte mso 9)|(IE)]>
    </td>
    </tr>
    </table>
    <![endif]-->
</td>