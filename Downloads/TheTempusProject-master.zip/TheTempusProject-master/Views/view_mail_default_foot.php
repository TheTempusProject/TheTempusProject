<td width="37" style="text-align: center; padding: 0 10px 0 10px;">
    <a href="{BASE}fb">
        <img src="{BASE}Images/facebook.png" width="37" height="37" alt="Facebook" border="0" style="height: auto;">
    </a>
</td>
<td width="37" style="text-align: center; padding: 0 10px 0 10px;">
    <a href="{BASE}">
        <img src="{BASE}Images/logo_white.png" width="37" height="37" alt="{SITENAME}" border="0" style="height: auto;">
    </a>
</td>
<td width="37" style="text-align: center; padding: 0 10px 0 10px;">
    <a href="{BASE}twitter">
        <img src="{BASE}Images/twitter.png" width="37" height="37" alt="Twitter" border="0" style="height: auto;">
    </a>
</td>